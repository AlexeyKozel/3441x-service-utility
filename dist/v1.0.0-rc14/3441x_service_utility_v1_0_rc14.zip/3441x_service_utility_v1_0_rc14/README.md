# 3441x Service Utility

An unofficial service and recovery utility for Agilent/Keysight 34410A and 34411A digital multimeters.

The current public release is **v1.0.0-rc14**. It provides a Windows GUI and a console interface for diagnostic reads, backups, offline package inspection, boot-identity maintenance, and controlled upload of original APP images.

> [!WARNING]
> This software can write persistent instrument storage and firmware. A failed operation or power loss can brick the instrument. Use it entirely at your own risk. The author accepts no responsibility for damaged equipment, data loss, or calibration issues. Read [SAFETY.md](SAFETY.md) before enabling any write operation.

RC14 expands calibration-table handling and coefficient interpretation: a searchable CAL viewer, current/historical slot comparison, filter curves, and explanations with formulas and physical units where established. See [release notes](CHANGELOG.md).

## Features

- Reads instrument identity and diagnostic information through VISA.
- Creates service-memory and native 64 KiB SA96 backups.
- Inspects NOR dumps, CAL payloads, and factory `.xs` packages offline.
- Simulates an `.xs` package against a copy of a NOR image.
- Switches the boot identity between 34410A and 34411A with exact read-back verification.
- Uploads original 34410A or 34411A APP `instrumentimage` packages.
- Uses progress reporting for long reads and writes.
- Stores backups in `3441x Service Utility Backups` beside the launched utility.

The repository contains no firmware, updater packages, instrument dumps, calibration data, or vendor binaries.

## Walkthrough

[docs/CONVERSION-WALKTHROUGH.md](docs/CONVERSION-WALKTHROUGH.md) is an
illustrated, step-by-step run of a complete boot-identity conversion and its
reversal on real hardware, including which order to use in each direction, what
the alarming-but-normal moments look like, and how to recover from the loader.

## Requirements

- Windows 10 or later
- Python 3.10 or later
- A VISA implementation compatible with your interface
- PyVISA

Install the Python dependency:

```powershell
py -m pip install -r requirements-live.txt
```

## Running the utility

GUI:

```powershell
run_gui.bat
```

Console help:

```powershell
run_cli.bat --help
```

Pass the VISA resource accepted by your VISA installation, for example `GPIB0::20::INSTR`.

## Write-operation behavior

Identity switching first saves the original SA96 sector, uploads a hash-bound patched package, and performs a complete read-back. The utility handles either an automatic reboot or an explicit reboot only after the programmed sector has been verified.

APP upload accepts only factory-format `instrumentimage` packages identified as 34410A or 34411A. Cross-loading between those two models is allowed after a simple Yes/No confirmation. General `updateimage` upload remains blocked.

After a native APP package is accepted, the instrument may remain at `UPDATING FIRMWARE`. This matches the original updater path: the utility asks for a manual power cycle and then waits for the instrument to reconnect. It deliberately does not send `:diag:reboot` for APP `instrumentimage` completion.

RC13 matches the OEM block transaction more closely: each acknowledgement is read with one bounded 100-byte VISA read, and the main block loop uses the OEM 5-second timeout. After a successful `END`, the manual power-cycle prompt is shown immediately without a premature reconnect attempt.

No firmware block or package is automatically retried after a timeout.

## Tests

```powershell
py -X utf8 -m unittest discover -s tests -v
```

Some evidence-bound tests are skipped when the private research artifacts are not present. The public tests and runtime do not require those artifacts.

## Building a release archive

```powershell
py -X utf8 build_release.py
```

The command creates a versioned ZIP and `SHA256SUMS.txt` under `dist/v1.0.0-rc14`.

## Project status

RC14 adds offline calibration analysis and has passed the offline regression suite. New hardware validation is not claimed for RC14.

RC13 was a hardware-validation release. The author successfully uploaded original 34410A and 34411A APP packages in sequence on real hardware and completed the required manual power cycles. This is not a warranty of safety or compatibility with every instrument, interface, firmware version, or recovery state.

This project is not affiliated with or endorsed by Keysight Technologies, Agilent Technologies, or Hewlett-Packard.

## License

The source code is available under the [MIT License](LICENSE). Vendor firmware, updater packages, instrument dumps, and calibration data are not included and are not licensed by this project.
